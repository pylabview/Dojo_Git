### Parent-Child_Siblin (PCS) Identification

### Parent
    - <html> is the root element
    - <html> has no parents
    - <html> is the parent of <head> and <body>
    - <head> is the first child of <html>
    - <body> is the last child of <html>

### Child- Sibling
    -<head> has one child: <title>
    -<title> has one content (text): "Hello World!"
    -<body> has three children: <table>, <h1> and <ul>
    -<h1> has one content (text): "Here is a list of my favorite things:"
    -<table>, <h1> and <ul> are siblings
    -<table> has two children: <thead> and <tbody>
    -<thead> and <tbody> are siblings 
    -<thead> has onw child: <tr>
    -<tr> has four children <th>
    -<th*4> are siblings  
    -<tbody> has three children of <td>
    -<ul> has four children: <li>
    -<li*4> are siblings
